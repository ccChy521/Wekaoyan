# WJBrepository

#中国地质大学（武汉）2018级综合实习

#组长：曾满

#组员：王金波、陈红宇、李书泽

#此项目名称是考研信息查询系统

#是基于springboot、mybatis框架搭建而成的web项目
