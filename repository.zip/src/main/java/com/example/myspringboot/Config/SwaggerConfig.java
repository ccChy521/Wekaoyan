package com.example.myspringboot.Config;

import org.omg.CORBA.Environment;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Profiles;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import java.util.ArrayList;

@Configuration
@EnableSwagger2  //开启swagger2
public class SwaggerConfig {

    //配置swagger的Bean实例
    @Bean
    public Docket getDocket(){
        return new Docket(DocumentationType.SWAGGER_2)
                .apiInfo(getApiInfo())
                .select()
                //RequestHandlerSelectors配置要扫描的方式
                .apis(RequestHandlerSelectors.basePackage("com.example.myspringboot.Controller"))
                //paths过滤路径
                .paths(PathSelectors.ant("/myspringboot/**"))
                .build();
    }

    //配置swagger信息,apiinfo
    @Bean
    public ApiInfo getApiInfo(){
        Contact contact=new Contact("wjb","https://www.bilibili.com/","1694300437@qq.com");
        return new ApiInfo(
                "wjb Document",
                "Api Documentation",
                "v1.0",
                "https://www.bilibili.com/",
                contact,"Apache 2.0",
                "http://www.apache.org/licenses/LICENSE-2.0",
                new ArrayList());
    }


}
