package com.example.myspringboot.Config;

import org.apache.shiro.authc.*;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;

public class UserRealm extends AuthorizingRealm {
    //授权
    @Override
    protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principalCollection) {
        System.out.println("doGetAuthorizationInfo");

        SimpleAuthorizationInfo info = new SimpleAuthorizationInfo();
        info.addStringPermission("user:add");

        return info;
    }

    //认证
    @Override
    protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken token) throws AuthenticationException {
        System.out.println("doGetAuthenticationInfo");

        //利用数据库数据
        /*User user = userMapper.queryByName(username);
        System.out.println(user);*/

        //设置当前的用户
        String username="wjb";
        String password="123";

        UsernamePasswordToken token1=(UsernamePasswordToken) token;
        if(!token1.getUsername().equals(username)){
            return null; //抛出异常，UnknownAccountException
        }
        //密码认证由shiro做
        return new SimpleAuthenticationInfo("",password,"");

    }
}
