package com.example.myspringboot.Controller;

import com.fasterxml.jackson.databind.annotation.JsonTypeResolver;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

@Controller
public class GetDayExercise {


    @RequestMapping("/getlistmathnovels")
    @ResponseBody
    public String getListMathNovels(HttpServletRequest request) throws IOException {
        int id=Integer.parseInt(request.getParameter("pageindex"));
        String URL="";
        if(id==1){
            URL="http://www.kaoyan.com/shuxue/lianxi/index.html";
        }else{
            URL = "http://www.kaoyan.com/shuxue/lianxi/index_"+id+".html";
        }
        Document doc= Jsoup.connect(URL).timeout(4000).get();
        Elements elements = doc.getElementsByClass("list areaZslist");
        Elements lis=elements.get(0).getElementsByTag("li");
        String res="";
        for(int i=0;i<lis.size();i++){
            Elements a=lis.get(i).getElementsByTag("a");
            String str=a.get(0).text();
            for(int j=0;j<str.length();j++){
                if(str.charAt(j)=='（'){
                    res+=i+1;
                    break;
                }
                res+=str.charAt(j);
            }
            if(i<lis.size()-1)res+="|";
        }
        return res;
    }

    @RequestMapping("/getlistmathlinks")
    @ResponseBody
    public String getListMathLinks(HttpServletRequest request) throws IOException {
        int id=Integer.parseInt(request.getParameter("pageindex"));
        String URL="";
        if(id==1){
            URL="http://www.kaoyan.com/shuxue/lianxi/index.html";
        }else{
            URL = "http://www.kaoyan.com/shuxue/lianxi/index_"+id+".html";
        }
        Document doc= Jsoup.connect(URL).timeout(4000).get();
        Elements elements = doc.getElementsByClass("list areaZslist");
        Elements lis=elements.get(0).getElementsByTag("li");
        String res="";
        for(int i=0;i<lis.size();i++){
            String link=lis.get(i).html();
            int index0=0,index1=0;
            for(int j=0;j<link.length();j++){
                if(link.substring(j,j+4).equals("http")){
                    index0=j;
                }
                if(link.substring(j,j+4).equals("html")){
                    index1=j;
                    break;
                }
            }
            res+=link.substring(index0,index1+4);
            if(i<lis.size()-1)res+="|";
        }
        return res;
    }

    @RequestMapping("/getlistpoliticnovels")
    @ResponseBody
    public String getListPoliticNovels(HttpServletRequest request) throws IOException {
        int id=Integer.parseInt(request.getParameter("pageindex"));
        String URL="";
        if(id==1){
            URL="http://www.kaoyan.com/zhengzhi/lianxi/index.html";
        }else{
            URL = "http://www.kaoyan.com/zhengzhi/lianxi/index_"+id+".html";
        }
        Document doc= Jsoup.connect(URL).timeout(4000).get();
        Elements elements = doc.getElementsByClass("list areaZslist");
        Elements lis=elements.get(0).getElementsByTag("li");
        String res="";
        for(int i=0;i<lis.size();i++){
            Elements a=lis.get(i).getElementsByTag("a");
            String str=a.get(0).text();
            for(int j=0;j<str.length();j++){
                if(str.charAt(j)=='（'){
                    res+=i+1;
                    break;
                }
                res+=str.charAt(j);
            }
            if(i<lis.size()-1)res+="|";
        }
        return res;
    }

    @RequestMapping("/getlistpoliticlinks")
    @ResponseBody
    public String getListPoliticLinks(HttpServletRequest request) throws IOException {
        int id=Integer.parseInt(request.getParameter("pageindex"));
        String URL="";
        if(id==1){
            URL="http://www.kaoyan.com/zhengzhi/lianxi/index.html";
        }else{
            URL = "http://www.kaoyan.com/zhengzhi/lianxi/index_"+id+".html";
        }
        Document doc= Jsoup.connect(URL).timeout(4000).get();
        Elements elements = doc.getElementsByClass("list areaZslist");
        Elements lis=elements.get(0).getElementsByTag("li");
        String res="";
        for(int i=0;i<lis.size();i++){
            String link=lis.get(i).html();
            int index0=0,index1=0;
            for(int j=0;j<link.length();j++){
                if(link.substring(j,j+4).equals("http")){
                    index0=j;
                }
                if(link.substring(j,j+4).equals("html")){
                    index1=j;
                    break;
                }
            }
            res+=link.substring(index0,index1+4);
            if(i<lis.size()-1)res+="|";
        }
        return res;
    }

    @RequestMapping("/getnovel")
    @ResponseBody
    public String getNovel(HttpServletRequest request) throws IOException {
        String URL=request.getParameter("link");
        System.out.println(URL);
        Document doc= Jsoup.connect(URL).timeout(4000).get();
        Elements elements = doc.getElementsByClass("articleCon");
        Elements strong=elements.get(0).getElementsByTag("strong");
        String str= strong.get(0).toString();
        return str;
    }

    @RequestMapping("/getnovel1")
    @ResponseBody
    public String getNovel1(HttpServletRequest request) throws IOException {
        String URL=request.getParameter("link");
        Document doc= Jsoup.connect(URL).timeout(4000).get();
        Elements elements = doc.getElementsByClass("articleCon");
        Elements strong=elements.get(0).getElementsByTag("strong");
        Elements img=elements.get(0).getElementsByTag("img");
        String str= strong.get(0).toString()+"<br>"+img.get(0).toString()+"<br><br>";
        return str;
    }


}
