package com.example.myspringboot.Controller;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

@Controller
public class GetRealNovels {

    private String[] mathlinks={
            "http://www.kaoyan.com/shuxue/zhenti/5e00676df2ce2.html",
            "http://www.kaoyan.com/shuxue/zhenti/5e0068f317659.html",
            "http://www.kaoyan.com/shuxue/zhenti/5e0068d60ab18.html",
            "http://www.kaoyan.com/shuxue/zhenti/5c1f577223e02.html",
            "http://www.kaoyan.com/shuxue/zhenti/5c1f5993647b4.html",
            "http://www.kaoyan.com/shuxue/zhenti/5c1f5a678691e.html",
            "http://www.kaoyan.com/shuxue/zhenti/5a3f6eaebd459.html",
            "http://www.kaoyan.com/shuxue/zhenti/5a3f39a11d59a.html",
            "http://www.kaoyan.com/shuxue/zhenti/5a3f6db0f1661.html",
            "http://www.kaoyan.com/shuxue/zhenti/585f8d308c823.html",
            "http://www.kaoyan.com/shuxue/zhenti/585f8f6fcd238.html",
            "http://www.kaoyan.com/shuxue/zhenti/585f90b3c27b7.html",
            "http://www.kaoyan.com/shuxue/zhenti/567fa40ed0fbe.html",
            "http://www.kaoyan.com/shuxue/zhenti/567f9503d3ccf.html",
            "http://www.kaoyan.com/shuxue/zhenti/567faf5395b45.html",
            "http://www.kaoyan.com/shuxue/zhenti/549fb231d5c93.html",
            "http://www.kaoyan.com/shuxue/zhenti/549fba593ee8d.html",
            "http://www.kaoyan.com/shuxue/zhenti/549f868b2fafb.html",
            "http://www.kaoyan.com/ky/05/533516/",
            "http://www.kaoyan.com/ky/05/533518/"
    };
    private String[] politiclinks={
            "http://www.kaoyan.com/zhengzhi/zhenti/5e005766940c9.html",
            "http://www.kaoyan.com/zhengzhi/zhenti/5c1f0626482e9.html",
            "http://www.kaoyan.com/zhengzhi/zhenti/5a3e0a875bd77.html",
            "http://www.kaoyan.com/zhengzhi/zhenti/585df3424ce0d.html",
            "http://www.kaoyan.com/zhengzhi/zhenti/5680a53bad9c1.html",
            "http://www.kaoyan.com/zhengzhi/zhenti/549f74e82abb0.html",
            "http://www.kaoyan.com/ky/04/533298/",
            "http://www.kaoyan.com/ky/06/469173/",
            "http://www.kaoyan.com/kaoyan/07/377304/",
            "http://www.kaoyan.com/kaoyan/15/331489/",
            "http://www.kaoyan.com/kaoyan/2010/01-09/30946/",
            "http://www.kaoyan.com/zhengzhi/zhenti/5e005766940c9.html",
            "http://www.kaoyan.com/zhengzhi/zhenti/5c1f0626482e9.html",
            "http://www.kaoyan.com/zhengzhi/zhenti/5a3e0a875bd77.html",
            "http://www.kaoyan.com/zhengzhi/zhenti/585df3424ce0d.html",
            "http://www.kaoyan.com/zhengzhi/zhenti/5680a53bad9c1.html",
            "http://www.kaoyan.com/zhengzhi/zhenti/549f74e82abb0.html",
            "http://www.kaoyan.com/ky/04/533298/",
            "http://www.kaoyan.com/ky/06/469173/",
            "http://www.kaoyan.com/kaoyan/07/377304/",
            "http://www.kaoyan.com/kaoyan/15/331489/",
            "http://www.kaoyan.com/kaoyan/2010/01-09/30946/"
    };
    private String[] Englishlinks={
            "http://www.kaoyan.com/yingyu/zhenti/5dfed9ca8947c.html",
            "http://www.kaoyan.com/yingyu/zhenti/5dfed9af2f8a7.html",
            "http://www.kaoyan.com/yingyu/zhenti/5c1ee39930066.html",
            "http://www.kaoyan.com/yingyu/zhenti/5c1ee42939f70.html",
            "http://www.kaoyan.com/yingyu/zhenti/5a3f19d797aff.html",
            "http://www.kaoyan.com/yingyu/zhenti/5a3f118397304.html",
            "http://www.kaoyan.com/yingyu/zhenti/585f2fc65e6eb.html",
            "http://www.kaoyan.com/yingyu/zhenti/5862076116454.html",
            "http://www.kaoyan.com/yingyu/zhenti/567fb17d5b521.html",
            "http://www.kaoyan.com/yingyu/zhenti/567fa5f09b46a.html",
            "http://www.kaoyan.com/yingyu/zhenti/54a20dcbd26ce.html",
            "http://www.kaoyan.com/yingyu/zhenti/54a20e7438705.html",
            "http://www.kaoyan.com/ky/05/533396/",
            "http://www.kaoyan.com/ky/06/533799/",
            "http://www.kaoyan.com/ky/06/533799/",
            "http://www.kaoyan.com/ky/06/533799/",
            "http://www.kaoyan.com/kaoyan/09/377537/",
            "http://www.kaoyan.com/kaoyan/09/377537/",
            "http://www.kaoyan.com/kaoyan/09/377537/",
            "http://www.kaoyan.com/kaoyan/09/377537/",
    };

    @RequestMapping("/realnovel")
    @ResponseBody
    public String getRealnovel(HttpServletRequest request) throws IOException {
        String URL = "";
        String coursename=request.getParameter("course");
        int index=Integer.parseInt(request.getParameter("index"));
        if(coursename.equals("math")){
            URL=mathlinks[index];
        }else if(coursename.equals("politic")){
            URL=politiclinks[index];
        }else if(coursename.equals("English")){
            URL=Englishlinks[index];
        }
        Document doc= Jsoup.connect(URL).timeout(4000).get();
        Elements elements = doc.getElementsByClass("articleCon");
        String res=elements.get(0).html();
        return res;
    }



}
