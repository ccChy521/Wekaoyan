package com.example.myspringboot.Controller;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

@Controller
public class GetRecommendMsg {

    @RequestMapping("/zhaoshengmsessages")
    @ResponseBody
    public String getZhaoShengMessages() throws IOException {
        String URL="http://www.kaoyan.com/zhaosheng/";
        Document doc= Jsoup.connect(URL).timeout(4000).get();
        Elements elements = doc.getElementsByClass("list areaZslist");
        Elements as=elements.get(0).getElementsByTag("a");
        String res="";
        for(int i=0;i<8;i++){
            String str=as.get(i).text();
            if(str.length()>=30){
                str=str.substring(0,29);
            }
            res+=str;
            if(i<7)res+=',';
        }
        return res;
    }

    @RequestMapping("/zhaoshenglinkmsessages")
    @ResponseBody
    public String getZhaoShenglinkMessages() throws IOException {
        String URL="http://www.kaoyan.com/zhaosheng/";
        Document doc= Jsoup.connect(URL).timeout(4000).get();
        Elements elements = doc.getElementsByClass("list areaZslist");
        Elements lis=elements.get(0).getElementsByTag("li");
        String res="";
        for(int k=0;k<8;k++){
            String link=lis.get(k).html();
            int index0=0,index1=0;
            for(int i=0;i<link.length();i++){
                if(link.substring(i,i+4).equals("http")){
                    index0=i;
                }
                if(link.substring(i,i+4).equals("html")){
                    index1=i;
                    break;
                }
            }
            res+=link.substring(index0,index1+4);
            if(k<7)res+=',';
        }
        return res;
    }

    @RequestMapping("/hotmsessages")
    @ResponseBody
    public String getHotMessages() throws IOException {
        String URL="http://www.kaoyan.com/hot/";
        Document doc= Jsoup.connect(URL).timeout(4000).get();
        Elements elements = doc.getElementsByClass("list areaZslist");
        Elements as=elements.get(0).getElementsByTag("a");
        String res="";
        for(int i=0;i<20;i++){
            String str=as.get(i).text();
            if(str.length()>=30){
                str=str.substring(0,29);
            }
            res+=str;
            if(i<19)res+=',';
        }
        return res;
    }

    @RequestMapping("/hotlinkmsessages")
    @ResponseBody
    public String getHotlinkMessages() throws IOException {
        String URL="http://www.kaoyan.com/hot/";
        Document doc= Jsoup.connect(URL).timeout(4000).get();
        Elements elements = doc.getElementsByClass("list areaZslist");
        Elements lis=elements.get(0).getElementsByTag("li");
        String res="";
        for(int k=0;k<20;k++){
            String link=lis.get(k).html();
            int index0=0,index1=0;
            for(int i=0;i<link.length();i++){
                if(link.substring(i,i+4).equals("http")){
                    index0=i;
                }
                if(link.substring(i,i+4).equals("html")){
                    index1=i;
                    break;
                }
            }
            res+=link.substring(index0,index1+4);
            if(k<19)res+=',';
        }
        return res;
    }

    @RequestMapping("/zhaoshengmsessage")
    @ResponseBody
    public String getZhaoShengMessage(HttpServletRequest request) throws IOException {
        String URL=request.getParameter("link");
        Document doc= Jsoup.connect(URL).timeout(4000).get();
        Elements elements = doc.getElementsByClass("articleCon");
        return elements.get(0).html();
    }


}
