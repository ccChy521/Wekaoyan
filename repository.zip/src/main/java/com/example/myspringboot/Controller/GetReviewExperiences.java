package com.example.myspringboot.Controller;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

@Controller
public class GetReviewExperiences {

    private String[] experiencelinks={
            "http://www.kaoyan.com/shuxue/jingyan/5f338fb36b6f7.html",
            "http://www.kaoyan.com/shuxue/jingyan/5f2223e695cb6.html",
            "http://www.kaoyan.com/shuxue/jingyan/5ef2b67c32160.html",
            "http://www.kaoyan.com/shuxue/jingyan/5efa9939422cb.html",
            "http://www.kaoyan.com/shuxue/jingyan/5ef166d0c8153.html",
            "http://www.kaoyan.com/zhengzhi/jingyan/5f857af38602f.html",
            "http://www.kaoyan.com/zhengzhi/jingyan/5f61e99f5bc2c.html",
            "http://www.kaoyan.com/zhengzhi/jingyan/5fb387c16279f.html",
            "http://www.kaoyan.com/zhengzhi/jingyan/5f3f73fa1a1bd.html",
            "http://www.kaoyan.com/zhengzhi/jingyan/5f3def3ede5b7.html",
            "http://www.kaoyan.com/yingyu/jingyan/5fec4d6360a0e.html",
            "http://www.kaoyan.com/yingyu/jingyan/5fd9d4c106942.html",
            "http://www.kaoyan.com/yingyu/jingyan/5fb79fc1c4460.html",
            "http://www.kaoyan.com/yingyu/jingyan/5f8954243c367.html",
            "http://www.kaoyan.com/yingyu/jingyan/5f61c67ee252a.html"
    };

    @RequestMapping("/experience")
    @ResponseBody
    public String getRealnovel(HttpServletRequest request) throws IOException {
        int id=Integer.parseInt(request.getParameter("index"));
        String URL=experiencelinks[id];
        Document doc= Jsoup.connect(URL).timeout(4000).get();
        Elements elements = doc.getElementsByClass("articleCon");
        String res=elements.get(0).html();
        return res;
    }
}
