package com.example.myspringboot.Controller;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

@Controller
public class GetSyllabus {
    private String[] syllabuslinks={
            "http://www.kaoyan.com/shuxue/jingyan/5d22aafee821c.html",
            "http://www.kaoyan.com/shuxue/jingyan/5d22ae42934a7.html",
            "http://www.kaoyan.com/shuxue/jingyan/5d22b283d280c.html",
            "http://www.kaoyan.com/shuxue/dagang/5d246ba616c95.html",
            "http://www.kaoyan.com/shuxue/dagang/5d25599ad5fba.html",
            "http://www.kaoyan.com/shuxue/jingyan/5d22ae42934a7.html",
            "http://www.kaoyan.com/yingyu/jingyan/5d22e118cdd08.html",
            "http://www.kaoyan.com/yingyu/dagang/5d245177d54bd.html",
            "http://www.kaoyan.com/yingyu/dagang/5d24585a99a6d.html",
            "http://www.kaoyan.com/yingyu/dagang/5d245ab316172.html",
            "http://www.kaoyan.com/zhengzhi/jingyan/5d22e3e66c468.html",
            "http://www.kaoyan.com/zhengzhi/dagang/5d243af22f3db.html",
            "http://www.kaoyan.com/zhengzhi/dagang/5d243b87241a4.html",
            "http://www.kaoyan.com/zhengzhi/dagang/5d243c4e99394.html",
            "http://www.kaoyan.com/zhengzhi/dagang/5d243d30205eb.html",
    };

    @RequestMapping("/syllabus")
    @ResponseBody
    public String getRealnovel(HttpServletRequest request) throws IOException {
        int id=Integer.parseInt(request.getParameter("index"));
        String URL=syllabuslinks[id];
        Document doc= Jsoup.connect(URL).timeout(4000).get();
        Elements elements = doc.getElementsByClass("articleCon");
        String res=elements.get(0).html();
        return res;
    }
}
