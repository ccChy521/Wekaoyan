package com.example.myspringboot.Controller;

import com.example.myspringboot.Dao.UserMassage;
import com.example.myspringboot.Pojo.UserMsg;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

@Controller
public class LoginOrRegister {

    @Autowired
    private UserMassage userMassage;

    @RequestMapping("/register")
    public String userRegister(HttpServletRequest request, String username, String password1, String password2){
        HttpSession session=request.getSession();
        if(password1.equals(password2)){
            UserMsg userMsg=new UserMsg();
            userMsg.setUsername(username);
            userMsg.setPassword(password1);
            userMassage.addUser(userMsg);
            session.setAttribute("username",username);
            //自动登录
            return "WeKaoYanHome";
        }else{
            session.setAttribute("feedback","密码不一致！");
        }
        return "WeKaoYanLoginOrRegister";
    }

    @RequestMapping("/login")
    public String userLogin(HttpServletRequest request,String username, String password){
        UserMsg userMsg=new UserMsg();
        userMsg.setUsername(username);
        userMsg.setPassword(password);
        UserMsg user= userMassage.selectUser(userMsg);
        HttpSession session=request.getSession();
        if(user.getUsername().equals(username)&&user.getPassword().equals(password)){
            session.setAttribute("username",username);
            return "WeKaoYanHome";
        }else{
            session.setAttribute("feedback","用户名或密码错误！");
        }
        return "WeKaoYanLoginOrRegister";
    }

}
