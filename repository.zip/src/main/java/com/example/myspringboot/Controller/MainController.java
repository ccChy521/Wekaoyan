package com.example.myspringboot.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MainController {

    @RequestMapping("/WeKaoYanHome")
    public String toWeKaoYanHome(){
        return "WeKaoYanHome";
    }

    @RequestMapping("/WeKaoYanLoginOrRegister")
    public String toWeKaoYanLoginOrRegister(){
        return "WeKaoYanLoginOrRegister";
    }

    @RequestMapping("/WeKaoYanRecommend")
    public String toWeKaoYanRecommend(){
        return "WeKaoYanRecommend";
    }

    @RequestMapping("/WeKaoYanSchool")
    public String toWeKaoYanSchool(){
        return "WeKaoYanSchool";
    }

    @RequestMapping("/WeKaoYanStudy")
    public String toWeKaoYanStudy(){
        return "WeKaoYanStudy";
    }

    @RequestMapping("/ContactWe")
    public String toContactWe(){
        return "ContactWe";
    }
    @RequestMapping("/DayExercise")
    public String toDayExercise(){
        return "DayExercise";
    }

    @RequestMapping("/PastRealNovel")
    public String toPastRealNovel(){
        return "PastRealNovel";
    }

    @RequestMapping("/ReviewExperience")
    public String toReviewExperience(){
        return "ReviewExperience";
    }

    @RequestMapping("/ExamSyllabus")
    public String toExamSyllabus(){
        return "ExamSyllabus";
    }

    @RequestMapping("/WordOrSentence")
    public String toWordOrSentence(){
        return "WordOrSentence";
    }

    @RequestMapping("/resourcesDownload")
    public String toresourcesDownoload(){
        return "resourcesDownoload";
    }

    @RequestMapping("/home")
    public String Home(){
        return "WeKaoYanHome";
    }


}
