package com.example.myspringboot.Controller;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

@Controller
public class WordOrSentence {

    @RequestMapping("/getlistwords")
    @ResponseBody
    public String getListWords(HttpServletRequest request) throws IOException {
        int id=Integer.parseInt(request.getParameter("pageindex"));
        String URL="";
        if(id==1){
            URL="http://www.kaoyan.com/english/words/index.html";
        }else{
            URL = "http://www.kaoyan.com/english/words/index_"+id+".html";
        }
        Document doc= Jsoup.connect(URL).timeout(4000).get();
        Elements elements = doc.getElementsByClass("list areaZslist");
        Elements li=elements.get(0).getElementsByTag("li");
        String res="";
        for(int i=0;i<li.size();i++){
            Elements a=li.get(i).getElementsByTag("a");
            res+=a.get(0).text();
            if(i<li.size()-1)res+="|";
        }
        return res;
    }

    @RequestMapping("/getword")
    @ResponseBody
    public String getWord(HttpServletRequest request) throws IOException {
        String word=request.getParameter("word");
        word=word.split("-")[1];
        String URL="http://www.kaoyan.com/english/words/"+word+"/";
        Document doc= Jsoup.connect(URL).timeout(4000).get();
        Elements elements = doc.getElementsByClass("articleCon");
        String str=elements.get(0).html();
        return str;
    }

    @RequestMapping("/getlistsentences")
    @ResponseBody
    public String getListSentences(HttpServletRequest request) throws IOException {
        int id=Integer.parseInt(request.getParameter("pageindex"));
        String URL = "http://www.kaoyan.com/english/grammar/index_"+id+".html";
        Document doc= Jsoup.connect(URL).timeout(4000).get();
        Elements elements = doc.getElementsByClass("list areaZslist");
        Elements li=elements.get(0).getElementsByTag("li");
        String res="";
        for(int i=0;i<li.size();i++){
            Elements a=li.get(i).getElementsByTag("a");
            String str=a.get(0).text();
            String str_1="";
            for(int j=0;j<str.length();j++){
                if((str.charAt(j)>='0'&&str.charAt(j)<='9')||str.charAt(j)=='.'){
                    continue;
                }else{
                    str_1+=str.charAt(j);
                    if(j==5)str_1+=" -";
                }
            }
            res+=str_1;
            if(i<li.size()-1)res+="|";
        }
        return res;
    }

    @RequestMapping("/getsentence")
    @ResponseBody
    public String getSentence(HttpServletRequest request) throws IOException {
        String word=request.getParameter("word");
        String URL="http://www.kaoyan.com/english/grammar/"+word+"/";
        Document doc= Jsoup.connect(URL).timeout(4000).get();
        Elements elements = doc.getElementsByClass("articleCon");
        String str=elements.get(0).html();
        return str;
    }

}
