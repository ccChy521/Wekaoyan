package com.example.myspringboot.Dao;

import com.example.myspringboot.Pojo.MathNovelMsg;
import com.example.myspringboot.Pojo.PoliticNovelMsg;
import io.swagger.models.auth.In;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Mapper //代表这是一个mybatis的Mapper类：Dao，
@Repository
public interface NovelMessage {
    MathNovelMsg selectMathById(Integer novel_id);
    PoliticNovelMsg selectPoliticById(Integer novel_id);
}
