package com.example.myspringboot.Dao;

import com.example.myspringboot.Pojo.UserMsg;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Mapper //代表这是一个mybatis的Mapper类：Dao，
@Repository
public interface UserMassage {
    void addUser(UserMsg userMsg);
    UserMsg selectUser(UserMsg userMsg);
}
