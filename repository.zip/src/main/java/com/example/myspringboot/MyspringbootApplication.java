package com.example.myspringboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

//程序主入口
@SpringBootApplication
public class MyspringbootApplication {
    //程序主入口
    public static void main(String[] args) {
        SpringApplication.run(MyspringbootApplication.class, args);
    }

}
