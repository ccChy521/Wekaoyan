package com.example.myspringboot.Pojo;

import java.io.Serializable;

public class MathNovelMsg implements Serializable {
    Integer novel_id;
    String novel_type;
    String novel_title;
    String novel_answer;

    @Override
    public String toString() {
        return novel_id +","+novel_type +","+ novel_title +","+ novel_answer;
    }

    public void setNovel_id(Integer novel_id) {
        this.novel_id = novel_id;
    }

    public void setNovel_type(String novel_type) {
        this.novel_type = novel_type;
    }

    public void setNovel_title(String novel_title) {
        this.novel_title = novel_title;
    }

    public void setNovel_answer(String novel_answer) {
        this.novel_answer = novel_answer;
    }

    public Integer getNovel_id() {
        return novel_id;
    }

    public String getNovel_type() {
        return novel_type;
    }

    public String getNovel_title() {
        return novel_title;
    }

    public String getNovel_answer() {
        return novel_answer;
    }
}
