document.getElementById('div41').style.display='none'
document.getElementById('nextword').style.display='none'
let p=document.getElementById('div2').getElementsByTagName('p')[0]
p.onclick=function (){
    document.getElementById('div4').getElementsByTagName('ul')[0].style.display='block'
    document.getElementById('nextpage').style.display='block'
    document.getElementById('nextword').style.display='none'
    document.getElementById('div41').style.display='none'
}

function getUrlParam(name){
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
    var r = window.location.search.substr(1).match(reg);
    if (r != null) {
        return unescape(r[2]);
    }
    return null;
}

var sentPageAJAX=function (url,pageindex){
    $.ajax({
        type: "GET",
        url: url,
        data: {"pageindex":pageindex},
        dataType:"text",
        success: function (result) {
            var words=result.split('|')
            var as=document.getElementById('div4').getElementsByTagName('a')
            for(var i=0;i<as.length;i++){
                as[i].innerText=words[i]
            }
        },
        error: function (err) {
            alert("fail")
        }
    })
}
var links;
var sentLinkAJAX=function (url,pageindex){
    $.ajax({
        type: "GET",
        url: url,
        data: {"pageindex":pageindex},
        dataType:"text",
        success: function (result) {
            links=result.split('|')
        },
        error: function (err) {
            alert("fail")
        }
    })
}
var sentNovelAJAX=function (url,link){
    $.ajax({
        type: "GET",
        url: url,
        data: {"link":link},
        dataType:"text",
        success: function (result) {
            document.getElementById('div41').innerHTML=result
        },
        error: function (err) {
            alert("fail")
        }
    })
}
if(getUrlParam('course')=='math'){
    p.innerText='数学随机练习'
    var pageindex1=1
    var current=0;
    sentPageAJAX('getlistmathnovels',pageindex1)
    sentLinkAJAX('getlistmathlinks',pageindex1)
    document.getElementById('nextpage').onclick=function (){
        pageindex1+=1
        current=0
        sentPageAJAX('getlistmathnovels',pageindex1)
        sentLinkAJAX('getlistmathlinks',pageindex1)
    }
    var as=document.getElementById('div4').getElementsByTagName('a')
    for(var i=0;i<as.length;i++){
        let j=i
        as[i].onclick=function (){
            document.getElementById('div4').getElementsByTagName('ul')[0].style.display='none'
            document.getElementById('nextpage').style.display='none'
            document.getElementById('nextword').style.display='block'
            document.getElementById('div41').style.display='block'
            current=j
            sentNovelAJAX('getnovel',links[current])
        }
    }
    document.getElementById('nextword').onclick=function (){
        current+=1
        if(current<as.length){
            sentNovelAJAX('getnovel',links[current])
        }
    }
}
else if(getUrlParam('course')=='politic'){
    p.innerText='政治随机练习'
    var pageindex1=1
    var current=0;
    sentPageAJAX('getlistpoliticnovels',pageindex1)
    sentLinkAJAX('getlistpoliticlinks',pageindex1)
    document.getElementById('nextpage').onclick=function (){
        pageindex1+=1
        current=0
        sentPageAJAX('getlistpoliticnovels',pageindex1)
        sentLinkAJAX('getlistpoliticlinks',pageindex1)
    }
    var as=document.getElementById('div4').getElementsByTagName('a')
    for(var i=0;i<as.length;i++){
        let j=i
        as[i].onclick=function (){
            document.getElementById('div4').getElementsByTagName('ul')[0].style.display='none'
            document.getElementById('nextpage').style.display='none'
            document.getElementById('nextword').style.display='block'
            document.getElementById('div41').style.display='block'
            current=j
            sentNovelAJAX('getnovel1',links[current])
        }
    }
    document.getElementById('nextword').onclick=function (){
        current+=1
        if(current<as.length){
            sentNovelAJAX('getnovel1',links[current])
        }
    }
}