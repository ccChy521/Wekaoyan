var title=document.getElementById('div2').getElementsByTagName('p')
title[0].onclick=function (){
    document.getElementById('div4').getElementsByTagName('ul')[0].style.display='block'
    document.getElementById('div41').style.display='none'
}

var sentAJAX=function (url,index){
    $.ajax({
        type: "GET",
        url: url,
        data:{"index":index},
        dataType:"text",
        success: function (result) {
            var div41=document.getElementById('div41')
            div41.style.display='block'
            div41.innerHTML=result
            document.getElementById('div4').getElementsByTagName('ul')[0].style.display='none'
        },
        error: function (err) {
            alert("fail")
        }
    })
}

var lis=document.getElementById('div4').getElementsByTagName('li')
for(var i=0;i<lis.length;i++){
    let j=i
    lis[i].onclick=function (){
        sentAJAX('syllabus',j)
    }
}