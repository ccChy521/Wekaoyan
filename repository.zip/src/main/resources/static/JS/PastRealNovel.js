document.getElementById('div2').getElementsByTagName('p')[0].onclick=function (){
    document.getElementsByTagName('ul')[0].style.display='block'
    document.getElementById('div41').style.display='none'
}

function getUrlParam(name){
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
    var r = window.location.search.substr(1).match(reg);
    if (r != null) {
        return unescape(r[2]);
    }
    return null;
}
var coursename
if(getUrlParam('course')=='math') {
    document.getElementById('div2').getElementsByTagName('p')[0].innerText='数学往年真题'
    var as=document.getElementById('div4').getElementsByTagName('a')
    as[0].innerText='2020年考研数学一真题解析'
    as[1].innerText='2020年考研数学二真题解析'
    as[2].innerText='2020年考研数学三真题解析'
    as[3].innerText='2019年考研数学一真题解析'
    as[4].innerText='2019年考研数学二真题解析'
    as[5].innerText='2019年考研数学三真题解析'
    as[6].innerText='2018年考研数学一真题解析'
    as[7].innerText='2018年考研数学二真题解析'
    as[8].innerText='2018年考研数学三真题解析'
    as[9].innerText='2017年考研数学一真题解析'
    as[10].innerText='2017年考研数学二真题解析'
    as[11].innerText='2017年考研数学三真题解析'
    as[12].innerText='2016年考研数学一真题解析'
    as[13].innerText='2016年考研数学二真题解析'
    as[14].innerText='2016年考研数学三真题解析'
    as[15].innerText='2015年考研数学一真题解析'
    as[16].innerText='2015年考研数学二真题解析'
    as[17].innerText='2015年考研数学三真题解析'
    as[18].innerText='2014年考研数学一真题解析'
    as[19].innerText='2014年考研数学二真题解析'
    coursename='math'
}
else if(getUrlParam('course')=='English') {
    document.getElementById('div2').getElementsByTagName('p')[0].innerText='英语往年真题'
    var as=document.getElementById('div4').getElementsByTagName('a')
    as[0].innerText='2020年考研英语一真题解析'
    as[1].innerText='2020年考研英语二真题解析'
    as[2].innerText='2019年考研英语一真题解析'
    as[3].innerText='2019年考研英语二真题解析'
    as[4].innerText='2018年考研英语一真题解析'
    as[5].innerText='2018年考研英语二真题解析'
    as[6].innerText='2017年考研英语一真题解析'
    as[7].innerText='2017年考研英语二真题解析'
    as[8].innerText='2016年考研英语一真题解析'
    as[9].innerText='2016年考研英语二真题解析'
    as[10].innerText='2015年考研英语一真题解析'
    as[11].innerText='2015年考研英语二真题解析'
    as[12].innerText='2014年考研英语一真题解析'
    as[13].innerText='2014年考研英语二真题解析'
    as[14].innerText='2013年考研英语一真题解析'
    as[15].innerText='2013年考研英语二真题解析'
    as[16].innerText='2012年考研英语一真题解析'
    as[17].innerText='2012年考研英语二真题解析'
    as[18].innerText='2011年考研英语一真题解析'
    as[19].innerText='2011年考研英语二真题解析'
    coursename='English'
}
else if(getUrlParam('course')=='politic') {
    document.getElementById('div2').getElementsByTagName('p')[0].innerText='政治往年真题'
    var as=document.getElementById('div4').getElementsByTagName('a')
    as[0].innerText='2020年考研政治真题解析'
    as[1].innerText='2019年考研政治真题解析'
    as[2].innerText='2018年考研政治真题解析'
    as[3].innerText='2017年考研政治真题解析'
    as[4].innerText='2016年考研政治真题解析'
    as[5].innerText='2015年考研政治真题解析'
    as[6].innerText='2014年考研政治真题解析'
    as[7].innerText='2013年考研政治真题解析'
    as[8].innerText='2012年考研政治真题解析'
    as[9].innerText='2011年考研政治真题解析'
    as[10].innerText='2010年考研政治真题解析'
    as[11].innerText='2009年考研政治真题解析'
    as[12].innerText='2008年考研政治真题解析'
    as[13].innerText='2007年考研政治真题解析'
    as[14].innerText='2006年考研政治真题解析'
    as[15].innerText='2005年考研政治真题解析'
    as[16].innerText='2004年考研政治真题解析'
    as[17].innerText='2003年考研政治真题解析'
    as[18].innerText='2002年考研政治真题解析'
    as[19].innerText='2001年考研政治真题解析'
    coursename='politic'
}

var sentAJAX=function (url,coursename,index){
    $.ajax({
        type: "GET",
        url: url,
        data: {"course": coursename,"index":index},
        dataType:"text",
        success: function (result) {
            var div41=document.getElementById('div41')
            div41.style.display='block'
            div41.innerHTML=result
            document.getElementById('div4').getElementsByTagName('ul')[0].style.display='none'
        },
        error: function (err) {
            alert("fail")
        }
    })
}
var realnovels=document.getElementById('div4').getElementsByTagName('p')
for(var i=0;i<realnovels.length;i++){
    let j=i
    realnovels[i].onclick=function (){
        sentAJAX('realnovel',coursename,j)
    }
}
