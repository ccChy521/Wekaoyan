var as1=document.getElementById('div42').getElementsByTagName('a')
var as2=document.getElementById('div43').getElementsByTagName('a')

document.getElementById('p1').onclick=function (){
    document.getElementById('div42').style.display='block'
    document.getElementById('div43').style.display='block'
    document.getElementById('div44').style.display='none'
}

//获取大学最新的招生信息,标题
var sentAJAX=function (url){
    $.ajax({
        type: "GET",
        url: url,
        dataType:"text",
        success: function (result) {
            var titles=result.split(',')
            for(var i=0;i<8;i++){
                if(i<4)as1[i].innerText=titles[i]
                if(i>=4)as2[i-4].innerText=titles[i]
            }
        },
        error: function (err) {
            alert("fail")
        }
    })
}
sentAJAX('zhaoshengmsessages')

//获取链接
var links
var sentlinkAJAX=function (url){
    $.ajax({
        type: "GET",
        url: url,
        dataType:"text",
        success: function (result) {
            links=result.split(',')
        },
        error: function (err) {
            alert("fail")
        }
    })
}
sentlinkAJAX('zhaoshenglinkmsessages')

//获取单个信息
var sentmsgAJAX=function (url,link){
    $.ajax({
        type: "GET",
        url: url,
        data:{"link":link},
        dataType:"text",
        success: function (result) {
            document.getElementById('div42').style.display='none'
            document.getElementById('div43').style.display='none'
            var div44=document.getElementById('div44')
            div44.style.display='block'
            div44.innerHTML=result
        },
        error: function (err) {
            alert("fail")
        }
    })
}
for(var i=0;i<as1.length;i++){
    let j=i;
    as1[i].onclick=function (){
        sentmsgAJAX('zhaoshengmsessage',links[j])
    }
}
for(var i=0;i<as2.length;i++){
    let j=i;
    as2[i].onclick=function (){
        sentmsgAJAX('zhaoshengmsessage',links[j+4])
    }
}



