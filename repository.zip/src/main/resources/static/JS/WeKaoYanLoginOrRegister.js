var btn1=document.getElementById('btn1')
var btn2=document.getElementById('btn2')
btn1.onclick=function (){
    document.getElementById('from1').style.display='none'
    document.getElementById('from2').style.display='block'
    btn1.style.display='none'
    btn2.style.display='block'
}
btn2.onclick=function (){
    document.getElementById('from2').style.display='none'
    document.getElementById('from1').style.display='block'
    btn2.style.display='none'
    btn1.style.display='block'
}