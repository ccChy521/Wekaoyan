//获取大学最新的招生信息,标题
var as=document.getElementById('div3').getElementsByTagName('a')
var sentAJAX=function (url){
    $.ajax({
        type: "GET",
        url: url,
        dataType:"text",
        success: function (result) {
            var titles=result.split(',')
            for(var i=0;i<as.length;i++){
                as[i].innerText=titles[i]
            }
        },
        error: function (err) {
            alert("fail")
        }
    })
}
sentAJAX('hotmsessages')

//获取链接
var links
var sentlinkAJAX=function (url){
    $.ajax({
        type: "GET",
        url: url,
        dataType:"text",
        success: function (result) {
            links=result.split(',')
        },
        error: function (err) {
            alert("fail")
        }
    })
}
sentlinkAJAX('hotlinkmsessages')

//获取单个信息
var sentmsgAJAX=function (url,link){
    $.ajax({
        type: "GET",
        url: url,
        data:{"link":link},
        dataType:"text",
        success: function (result) {
            document.getElementById('div31').innerHTML=result
        },
        error: function (err) {
            alert("fail")
        }
    })
}
for(var i=0;i<as.length;i++){
    let j=i
    as[i].onclick=function (){
        document.getElementById('div3').getElementsByTagName('ul')[0].style.display='none'
        document.getElementById('div31').style.display='block'
        document.getElementById('title').innerText=as[j].innerText
        sentmsgAJAX('zhaoshengmsessage',links[j])
    }
}

document.getElementById('title').onclick=function (){
    document.getElementById('title').innerText='热点资讯'
    document.getElementById('div3').getElementsByTagName('ul')[0].style.display='block'
    document.getElementById('div31').style.display='none'
}
