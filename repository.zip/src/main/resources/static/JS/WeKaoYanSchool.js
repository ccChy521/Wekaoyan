var schools=document.getElementById('div2').getElementsByTagName('a')
var schoolshot=schools[0]
var schools985=schools[1]
var schools211=schools[2]
var schoolsarea=schools[3]

var flag1=false
schoolshot.onmouseover=function (){
    var math_div1=document.getElementById('div31')
    math_div1.style.display='block'
    math_div1.onmouseover=function (){
        math_div1.style.display='block'
        flag1=true
    }
    math_div1.onmouseout=function (){
        math_div1.style.display='none'
        flag1=false
    }
}
schoolshot.onmouseout=function (){
    if(flag1){
        //鼠标停留在div1上
    }else{
        document.getElementById('div31').style.display='none'
    }
}

var flag2=false
schools985.onmouseover=function (){
    var politic_div1=document.getElementById('div32')
    politic_div1.style.display='block'
    politic_div1.onmouseover=function (){
        politic_div1.style.display='block'
        flag2=true
    }
    politic_div1.onmouseout=function (){
        politic_div1.style.display='none'
        flag2=false
    }
}
schools985.onmouseout=function (){
    if(flag2){
        //鼠标停留在div1上
    }else{
        document.getElementById('div32').style.display='none'
    }
}

var flag3=false
schools211.onmouseover=function (){
    var English_div1=document.getElementById('div33')
    English_div1.style.display='block'
    English_div1.onmouseover=function (){
        English_div1.style.display='block'
        flag3=true
    }
    English_div1.onmouseout=function (){
        English_div1.style.display='none'
        flag3=false
    }
}
schools211.onmouseout=function (){
    if(flag3){
        //鼠标停留在div1上
    }else{
        document.getElementById('div33').style.display='none'
    }
}

var flag4=false
schoolsarea.onmouseover=function (){
    var download_div1=document.getElementById('div34')
    download_div1.style.display='block'
    download_div1.onmouseover=function (){
        download_div1.style.display='block'
        flag4=true
    }
    download_div1.onmouseout=function (){
        download_div1.style.display='none'
        flag4=false
    }
}
schoolsarea.onmouseout=function (){
    if(flag4){
        //鼠标停留在div1上
    }else{
        document.getElementById('div34').style.display='none'
    }
}