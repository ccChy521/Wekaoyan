document.getElementById('div41').style.display='none'
document.getElementById('nextword').style.display='none'
var p=document.getElementById('div2').getElementsByTagName('p')[0]
p.onclick=function (){
    p.innerText='英语热门单词及例句'
    document.getElementById('div4').getElementsByTagName('ul')[0].style.display='block'
    document.getElementById('nextpage').style.display='block'
    document.getElementById('nextword').style.display='none'
    document.getElementById('div41').style.display='none'
}

function getUrlParam(name){
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
    var r = window.location.search.substr(1).match(reg);
    if (r != null) {
        return unescape(r[2]);
    }
    return null;
}

var sentPageAJAX=function (url,pageindex){
    $.ajax({
        type: "GET",
        url: url,
        data: {"pageindex":pageindex},
        dataType:"text",
        success: function (result) {
            var words=result.split('|')
            var as=document.getElementById('div4').getElementsByTagName('a')
            for(var i=0;i<as.length;i++){
                as[i].innerText=words[i]
            }
        },
        error: function (err) {
            alert("fail")
        }
    })
}
var sentWSAJAX=function (url,word,flag){
    $.ajax({
        type: "GET",
        url: url,
        data: {"word":word},
        dataType:"text",
        success: function (result) {
            document.getElementById('div2').getElementsByTagName('p')[0].innerText=flag
            document.getElementById('div41').innerHTML=result
        },
        error: function (err) {
            alert("fail")
        }
    })
}
if(getUrlParam('type')=='word'){
    var pageindex1=1
    sentPageAJAX('getlistwords',pageindex1)
    document.getElementById('nextpage').onclick=function (){
        pageindex1+=1
        sentPageAJAX('getlistwords',pageindex1)
    }
    var as=document.getElementById('div4').getElementsByTagName('a')
    for(var i=0;i<as.length;i++){
        let j=i
        as[i].onclick=function (){
            document.getElementById('div4').getElementsByTagName('ul')[0].style.display='none'
            document.getElementById('nextpage').style.display='none'
            document.getElementById('nextword').style.display='block'
            document.getElementById('div41').style.display='block'
            var title=j+1+'-'+as[j].innerText
            sentWSAJAX('getword',title,title)
        }
    }
    document.getElementById('nextword').onclick=function (){
        var number=parseInt(document.getElementById('div2').getElementsByTagName('p')[0].innerText.split('-')[0])
        if(number<as.length){
            var title=number+1+'-'+as[number].innerText
            sentWSAJAX('getword',title,title)
        }
    }

}else if(getUrlParam('type')=='sentence'){
    var pageindex2=6
    var index=485636
    var current=0
    sentPageAJAX('getlistsentences',pageindex2)
    document.getElementById('nextpage').onclick=function (){
        pageindex2+=1
        index+=20
        current=0
        sentPageAJAX('getlistsentences',pageindex2)
    }
    var as=document.getElementById('div4').getElementsByTagName('a')
    for(var i=0;i<as.length;i++){
        let j=i
        as[i].onclick=function (){
            document.getElementById('div4').getElementsByTagName('ul')[0].style.display='none'
            document.getElementById('nextpage').style.display='none'
            document.getElementById('nextword').style.display='block'
            document.getElementById('div41').style.display='block'
            var title=as[j].innerText
            sentWSAJAX('getsentence',index+j,title)
            current=j
        }
    }
    document.getElementById('nextword').onclick=function (){
        current+=1
        var title=as[current].innerText
        sentWSAJAX('getsentence',index+current,title)
    }
}