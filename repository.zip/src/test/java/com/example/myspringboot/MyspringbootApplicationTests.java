package com.example.myspringboot;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyspringbootApplicationTests {

//    @Autowired
//    private Dog dog;
//    @Autowired
//    private Person person;
//    @Autowired
//    DataSource dataSource;
//    @Autowired
//    @Qualifier("redisTemplate")
//    RedisTemplate redisTemplate;
//
//
//    @Test
//    void contextLoads() {
//        System.out.println(dog);
//        System.out.println(person);
//    }
//    //测试数据库
//    @Test
//    void testDataSources() throws SQLException {
//        System.out.println(dataSource.getClass());
//        Connection connection=dataSource.getConnection();
//        System.out.println(connection);
//        connection.close();
//    }
//
//    //测试Redis
//    @Test
//    void testRedis() throws JsonProcessingException {
//        //redisTemplate 操作不同的数据类型，api和我们的指令一样
//        //opsForValue 操作字符串，类似于String
//        //opsForList 操作list集合
//
//        /*
//        获取redis的连接对象
//        RedisConnection connection = redisTemplate.getConnectionFactory().getConnection();
//        connection.flushDb(); //删除当前数据库的值
//        connection.flushAll(); //删除所有数据库的值
//        */
//        //redisTemplate.opsForValue().set("name1","wjb");
//        //System.out.println(redisTemplate.opsForValue().get("name1"));
//
//        //使用json来传递对象，利用json序列化
//        User user=new User(1,"wjb","happy");
//        String jsonUser = new ObjectMapper().writeValueAsString(user);
//        redisTemplate.opsForValue().set("name1",jsonUser);
//        System.out.println(redisTemplate.opsForValue().get("name1"));
//    }

}
