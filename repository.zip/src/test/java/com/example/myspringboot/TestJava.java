package com.example.myspringboot;

import com.example.myspringboot.Pojo.MathNovelMsg;
import com.example.myspringboot.Pojo.UserMsg;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import java.io.IOException;

@SpringBootTest
public class TestJava {

    @Test
    public void testString() throws IOException {
        String res="sds";
        System.out.println(res=="sds");
    }

}
